//
//  LoginViewModel.swift
//  Test
//
//  Created by Kareddy Hemanth Reddy on 24/10/23.
//

import Foundation
import FirebaseAuth

@MainActor
final class LoginViewModel:ObservableObject{
    
    @Published var email = ""
    @Published var password = ""
    @Published var isSignedIn:Bool = false
    
    
    func signIn(){
        guard !email.isEmpty, !password.isEmpty else{
            print("No Email or Password found")
            return
        }
        
        Task{
            do{
                let returnedUserData = try await AuthenticationManager.shared.signIn(email: email, password: password)
            isSignedIn = true
                print("Success")
                print(returnedUserData)
            }catch{
                print("Erro \(error)")
            }
        }
    }
    
    func signOut() async throws{
        do{
            try await AuthenticationManager.shared.signOut()
          isSignedIn = false
        }
        catch{
            print("Error Signin Out")
        }
       
    }
}
