//
//  LoginView.swift
//  Test
//
//  Created by Kareddy Hemanth Reddy on 24/10/23.
//

import SwiftUI

struct LoginView: View {
    
    
    @StateObject private var loginViewModel = LoginViewModel()
    
    var body: some View {
        
        if loginViewModel.isSignedIn == false {
            ZStack {
                Color("BgColor").ignoresSafeArea()
                
                VStack{
                    
                    Spacer()
                    
                    Text("Sign In")
                        .font(.title)
                        .fontWeight(.bold)
                        .padding(.bottom,30)
                    
                    VStack{
                        TextField("Enter your email", text: $loginViewModel.email)
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.white)
                    .clipShape(RoundedRectangle(cornerRadius: 50))
                    .padding(.horizontal)
                    .padding(.bottom)
                    
                    
                    
                    SecureField("Enter your password", text: $loginViewModel.password)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.white)
                        .clipShape(RoundedRectangle(cornerRadius: 50))
                        .padding(.horizontal)
                        .padding(.bottom)
                    
                    
                    Text("Sign In")
                        .font(.title3)
                        .fontWeight(.bold)
                        .foregroundStyle(Color.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color("MainColor"))
                        .clipShape(RoundedRectangle(cornerRadius: 50))
                        .padding(.horizontal)
                        .onTapGesture {
                            loginViewModel.signIn()
                        }
                    
                    Spacer()
                }
            }
        }
        else{
            VendorListView()
        }
    }
}

#Preview {
    LoginView()
}
