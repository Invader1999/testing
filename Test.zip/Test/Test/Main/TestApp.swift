//
//  TestApp.swift
//  Test
//
//  Created by Kareddy Hemanth Reddy on 24/10/23.
//
import SwiftUI
import FirebaseCore

class AppDelegate: NSObject, UIApplicationDelegate {
  func application(_ application: UIApplication,
                   didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
    FirebaseApp.configure()
    return true
  }
}

@main
struct YourApp: App {
  // register app delegate for Firebase setup
  @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    
    @State var showWelcomeView:Bool = false

  var body: some Scene {
    WindowGroup {
        let authuser = try? AuthenticationManager.shared.getAUthenticatedUser()
        
        NavigationStack {
            if authuser == nil && AuthenticationManager.shared.issignedIn == false{
                WelcomeView()
            }
            else{
                VendorListView()
            }

        }
    }
  }
}
