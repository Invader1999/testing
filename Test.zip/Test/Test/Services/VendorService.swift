//
//  VendorService.swift
//  Test
//
//  Created by Kareddy Hemanth Reddy on 24/10/23.
//


import Foundation
import Firebase
import FirebaseStorage
import FirebaseFirestoreSwift


actor VendorService {
    
    static let shared = VendorService()
    
    func saveVendorImage(imageData: UIImage) async throws ->String? {
        guard let imageData = imageData.jpegData(compressionQuality: 0.5) else{return nil}
        let storageRef = Storage.storage().reference(withPath: "vendor_images/\(UUID().uuidString)")
        
        do {
            let _ = try await storageRef.putDataAsync(imageData)
            let downloadURL = try await storageRef.downloadURL()
            return downloadURL.absoluteString
        } catch {
            throw error
        }
    }
    
    func saveVendorToFirestore(name: String, imageURL: String?,vendorID:String) async throws {
        let db = Firestore.firestore()
        let vendorData: [String: Any] = [
            "name": name,
            "imageURL": imageURL as Any,
            "vendorID":vendorID
        ]
        
        do {
            _ = try await db.collection("vendors").addDocument(data: vendorData)
        } catch {
            throw error
        }
    }
    
    
    //            func getVendors() async throws -> [Vendor] {
    //                    let db = Firestore.firestore()
    //                    let vendorsCollection = db.collection("vendors")
    //
    //                    do {
    //                        let querySnapshot = try await vendorsCollection.getDocuments()
    //                        var vendors = [Vendor]()
    //
    //                        for document in querySnapshot.documents {
    //                            if let data = document.data() as? [String: Any],
    //                               let name = data["name"] as? String,
    //                               let imageURL = data["imageURL"] as? String {
    //                               // Create a Vendor object and add it to the array
    //                                let vendor = Vendor(name: name, imageURL: imageURL)
    //                               vendors.append(vendor)
    //                            }
    //                        }
    //
    //                        return vendors
    //                    } catch {
    //                        throw error
    //                    }
    //                }
    
    
    func startListeningForVendorUpdates(completion: @escaping ([Vendor]?, Error?) -> Void) {
        let db = Firestore.firestore()
        let vendorsCollection = db.collection("vendors")
        
        // Create a listener to monitor changes in the 'vendors' collection.
        let _ = vendorsCollection.addSnapshotListener { querySnapshot, error in
            if let error = error {
                completion(nil, error)
                return
            }
            
            var vendors = [Vendor]()
            for document in querySnapshot!.documents {
                if let data = document.data() as? [String: Any],
                   let name = data["name"] as? String,
                   let imageURL = data["imageURL"] as? String ,
                   let vendorID = data["vendorID"] as? String{
                    let vendor = Vendor(name: name, imageURL: imageURL,vendorID:vendorID )
                    vendors.append(vendor)
                }
            }
            
            completion(vendors, nil)
        }
        
    }
    
}




//    private func imageContentType(data: Data) -> String {
//        if data.starts(with: [0xFF, 0xD8]) {
//            return "image/jpeg"
//        } else if data.starts(with: [0x89, 0x50, 0x4E, 0x47]) {
//            return "image/png"
//        } else {
//            return "application/octet-stream"
//        }
//    }
