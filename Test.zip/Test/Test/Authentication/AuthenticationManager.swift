//
//  AuthenticationManager.swift
//  Test
//
//  Created by Kareddy Hemanth Reddy on 24/10/23.
//


import Foundation
import FirebaseAuth

final class AuthenticationManager{
    
    @Published var issignedIn:Bool = false
    
    static let shared = AuthenticationManager()
    private init(){}
    

    func createUser(email:String,password:String)async throws -> AuthDataModel{
        
        let authDataResult = try await Auth.auth().createUser(withEmail: email, password: password)
        issignedIn = true
        return AuthDataModel(user: authDataResult.user)
    }
    
    func signIn(email: String, password: String) async throws -> AuthDataModel {
      let authDataResult = try await Auth.auth().signIn(withEmail: email, password: password)
    issignedIn = true
      return AuthDataModel(user: authDataResult.user)
    }
    
    func getAUthenticatedUser()throws ->AuthDataModel{
        guard let user = Auth.auth().currentUser else{
            throw URLError(.badServerResponse)
        }
        return AuthDataModel(user: user)
    }
    
    func signOut() async throws{
        do {
            try Auth.auth().signOut()
            issignedIn = false
            print("Sign out successful")
        } catch {
            print("Error while signing out: \(error)")
        }
    }

}


