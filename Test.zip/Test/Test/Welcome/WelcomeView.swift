//
//  WelcomeView.swift
//  Test
//
//  Created by Kareddy Hemanth Reddy on 24/10/23.
//

import SwiftUI

struct WelcomeView: View {
    
   
    var body: some View {
        ZStack {
            Color("BgColor").ignoresSafeArea()
            VStack{
                Spacer()
                Image(uiImage: UIImage(named: "LandingImage")!)
                    .resizable()
                    .scaledToFit()
                    .clipShape(Circle())
                
                Spacer()
                NavigationLink {
                    LoginView()
                        
                }label:{
                    PrimaryButton(title: "Sign In")
                }

                NavigationLink {
                    CreateUserView()
                } label: {
                    Text("Sign Up")
                        .font(.title3)
                        .fontWeight(.bold)
                        .foregroundStyle(Color("MainColor"))
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.white)
                        .clipShape(RoundedRectangle(cornerRadius: 50))
                        .shadow(color: .black.opacity(0.08), radius: 60,y: 16.0)
                        .padding(.vertical)
                }
                
                
            }
            .padding()
        }
        
    }
}

#Preview {
    NavigationStack{
        WelcomeView()
    }
}

struct PrimaryButton: View {
    
    var title:String
    
    var body: some View {
        Text(title)
            .font(.title3)
            .fontWeight(.bold)
            .foregroundStyle(Color.white)
            .frame(maxWidth: .infinity)
            .padding()
            .background(Color("MainColor"))
            .clipShape(RoundedRectangle(cornerRadius: 50))
    }
}
