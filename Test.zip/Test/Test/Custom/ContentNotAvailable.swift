//
//  ContentNotAvailable.swift
//  Test
//
//  Created by Kareddy Hemanth Reddy on 24/10/23.
//

import SwiftUI

struct ContentNotAvailable: View {
    var body:  some View{
            ContentUnavailableView {
                Label("No Vendors", systemImage: "exclamationmark.triangle.fill")
            } description: {
                Text("Vendors Added Will Be Displayed Here")
            }
    }
}

#Preview {
    ContentNotAvailable()
}
