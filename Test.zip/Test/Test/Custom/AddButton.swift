//
//  AddButton.swift
//  Test
//
//  Created by Kareddy Hemanth Reddy on 24/10/23.
//

import SwiftUI


struct AddButton<Content>: View where Content: View {
    @State var showSheet:Bool = false
    var content: () -> Content
    var title:String
    
    var body: some View {
        ZStack{
            HStack{
                Text(title)
                Image(systemName: "plus.circle.fill")
                    .font(.title)
                    
            }
            .background(Color.black)
            .foregroundStyle(Color.white)
            .onTapGesture {
                showSheet.toggle()
            }
            .sheet(isPresented: $showSheet, content: {
                content()
            })
            .padding()
            .background(Color.black)
            .clipShape(RoundedRectangle(cornerRadius: 50))
            .padding(.bottom)
            .shadow(color: .black.opacity(0.08), radius: 60,y: 16.0)
        }
    }
}


//#Preview {
//    AddButton(content: {
//        AddVendorView()
//    }, title: "Add Vendor")
//}
