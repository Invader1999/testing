//
//  CardView.swift
//  Test
//
//  Created by Kareddy Hemanth Reddy on 24/10/23.
//

import SwiftUI

import SwiftUI

struct CardView: View {
    let vendor: Vendor

    var body: some View {
        RoundedRectangle(cornerRadius: 10)
            .fill(.white)
            .shadow(color: Color.black.opacity(0.2), radius: 4, x: 0, y: 2)
            .overlay(
                VStack(alignment: .leading) {
                    VStack(alignment:.leading){
                        AsyncImage(url: URL(string: vendor.imageURL)) { phase in
                            switch phase {
                            case .empty:
                                ProgressView()
                            case .success(let image):
                                image.resizable()
                                    .clipShape(RoundedRectangle(cornerRadius: 10))
                                    .alignmentGuide(.leading) { d in
                                        d[.leading]
                                    }
                                    .frame(maxWidth:.infinity)
                            case .failure:
                                Image(systemName: "photo")
                            default:
                                EmptyView()
                            }
                        }
                    }

                    Text(vendor.name)
                        .font(.title3)
                        .fontWeight(.bold)
                        .foregroundStyle(Color.black)
                }
                
                .padding()
            )
            .padding(.horizontal)
    }
}
