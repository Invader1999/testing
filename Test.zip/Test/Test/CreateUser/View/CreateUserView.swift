//
//  CreateUserView.swift
//  Test
//
//  Created by Kareddy Hemanth Reddy on 24/10/23.
//

import SwiftUI

import SwiftUI

struct CreateUserView: View {
    
   @StateObject private var viewModel = CreateUserViewModel()
    
    var body: some View {
        
//        if !viewModel.sigupSuccess {
            ZStack {
                Color("BgColor").ignoresSafeArea()
                
                VStack{
                    
                    Spacer()
                    
                    Text("Sign Up")
                        .font(.title)
                        .fontWeight(.bold)
                        .padding(.bottom,30)
                    
                    VStack{
                        TextField("Enter your email", text: $viewModel.email)
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.white)
                    .clipShape(RoundedRectangle(cornerRadius: 50))
                    .padding(.horizontal)
                    .padding(.bottom)
                    
                        
                    
                    SecureField("Enter your password", text: $viewModel.password)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.white)
                        .clipShape(RoundedRectangle(cornerRadius: 50))
                        .padding(.horizontal)
                        .padding(.bottom)
                    
                    
                    Text("Sign In")
                        .font(.title3)
                        .fontWeight(.bold)
                        .foregroundStyle(Color.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color("MainColor"))
                        .clipShape(RoundedRectangle(cornerRadius: 50))
                        .padding(.horizontal)
                        .onTapGesture {
                            viewModel.signUp()
                        }
                    
                    Spacer()
                }
            }
        }
//        else{
//            VendorListView()
//                .navigationBarBackButtonHidden()
//        }
//    }
}


#Preview {
    CreateUserView()
}
