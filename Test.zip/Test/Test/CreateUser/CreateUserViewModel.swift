//
//  CreateUserViewModel.swift
//  Test
//
//  Created by Kareddy Hemanth Reddy on 24/10/23.
//

import Foundation


@MainActor
final class CreateUserViewModel:ObservableObject{
    
    @Published var email = ""
    @Published var password = ""
//    @Published var sigupSuccess = false
    
    
    func signUp(){
        guard !email.isEmpty, !password.isEmpty else{
            print("No Email or Password found")
            return
        }
        
        Task{
            do{
                let returnedUserData = try await AuthenticationManager.shared.createUser(email: email, password: password)
//                sigupSuccess = true
                email = ""
                password = ""
                print("Success")
                print(returnedUserData)
            }catch{
                print("Erro \(error)")
            }
        }
    }
    
}
